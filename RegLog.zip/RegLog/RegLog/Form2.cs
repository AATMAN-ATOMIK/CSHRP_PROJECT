﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RegLog
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtemaillogin.Text != "" && txtpwd.Text != "")
            {
                String s = "select * from registration where email='" + txtemaillogin.Text + "' and password='" + txtpwd.Text + "'";
                SqlDataAdapter d = new SqlDataAdapter(s, Class1.cn);
                DataTable t = new DataTable();
                d.Fill(t);
                if (t.Rows.Count > 0)
                {
                    Home h1 = new Home();
                    h1.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please Check Your Email And Password..");
                }
            }
            else
            {
                MessageBox.Show("Please Enter Values...");
            }
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}

