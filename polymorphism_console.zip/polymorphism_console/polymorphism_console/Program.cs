﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polymorphism_console
{
    public class Base
    {
        int a = 10;
        public void show()
        {
            Console.WriteLine("This is base show and a = " + a);
        }
        public void show(int n)
        {
            this.a = n;
            Console.WriteLine("This is base show and a = " + a);
        }
    }
    public class Derived : Base
    {
        int a = 10;
        public void show()
        {
            Console.WriteLine("This is derived show and a = " + a);
        }
        public void show(int n)
        {
            this.a = n;
            Console.WriteLine("This is derived show and a = " + a);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Derived d = new Derived();
            d.show();
            d.show(100);

            Base b = new Derived();
            b.show();
            b.show(20);
            Console.Read();
        }
    }
}
