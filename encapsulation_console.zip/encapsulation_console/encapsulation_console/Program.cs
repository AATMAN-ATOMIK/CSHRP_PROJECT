﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace encapsulation_console
{
    class Accmod
    { 
        private string name;
        protected string name2;
        public string name3;
       
        //for private
        public string namegetter
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        //for protected
        public string name2getter
        {
            get
            {
                return name2;
            }
            set
            {
                name2 = value;
            }
        }

        public void showpvt()
        {
            Console.WriteLine("name caught by namegetter and name2getter and public value : " + name + " " + name2 + name3);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Accmod a = new Accmod();
            a.namegetter = "Aatman";
            a.name2getter = "Kacha";
            a.name3 = "(ATOMIK)";
            a.showpvt();
            Console.Read();
        }
    }
}
