﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace inherit_console
{
    public class ATOMIK
    {
        public string name;
        public string address;
        public ATOMIK()
        {
            name = "";
            address = "";
        }
        public ATOMIK(string s1, string s2)
        {
            name = s1;
            address = s2;
        }

    }
    public class AK : ATOMIK
    {
        public string c;
        public AK()
        {
            c = "";
        }
        public AK(string s1 , string s2 , string s3) : base(s1,s2)
        {
            c = s3;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            AK a = new AK("Aatman","Rajkot - 360007","FOR C IN DERIVED");
            Console.WriteLine(a.name);
            Console.WriteLine(a.address);
            Console.WriteLine(a.c);
            Console.ReadLine();
        }
    }
}
