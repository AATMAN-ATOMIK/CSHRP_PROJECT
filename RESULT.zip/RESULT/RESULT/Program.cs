﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class result {
    public int rlno;
    public int total=0;
    public String nm;
    public int[] m = new int[5];
    public char grade; 
    //Scanner sc = new Scanner(System.in);

    public void get()
    {
        Console.WriteLine("Enter rlno : ");
        rlno=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter your name : ");
        nm=Convert.ToString(Console.ReadLine());
        
        for(int i=0 ; i<=3 ; i++)
        {
            Console.WriteLine("Enter mark");
            m[i]=Convert.ToInt32(Console.ReadLine());
            total=total + m[i];
        }
        if (total / 4 >= 90)
        {
            grade = 'A';
        }
        else if (total / 4 < 90 && total / 4 >= 70)
        {
            grade = 'B';
        }
        else if (total / 4 < 70 && total / 4 >= 50)
        {
            grade = 'c';
        }
        else if (total / 4 < 50 && total / 4 >= 40)
        {
            grade = 'D';
        }
        else 
        {
            grade = 'f';
        }
    }
    public void disp() {
        Console.WriteLine("Rollno : " + rlno + "Name : " + nm);
        for(int j=0 ; j<3 ; j++)
        {
            Console.WriteLine("Mark : "+ m[j]);        
        }
        Console.WriteLine("Total : " + total + "Grade : " + grade);
    }
    
    public static void Main(String[] args) {
        result r = new result();
        Console.WriteLine("Enter total no of Student : ");
        int no = Convert.ToInt32(Console.ReadLine());
        for(int k=0;k<=no;k++)
        {
            r.get();
            r.disp();
        }
    }
}
