﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace updatedeletevs10
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sel = "Select * from updet where name = '" + textBox1.Text + "'";
            SqlDataAdapter dsel = new SqlDataAdapter(sel,Class1.cn);
            DataTable dtsel = new DataTable();
            dsel.Fill(dtsel);
            if (dtsel.Rows.Count != 0)
            {
                redirect();
            }
            else
            {
                MessageBox.Show("User does not exists register first!!!","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }

        private void redirect()
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }
    }
}
