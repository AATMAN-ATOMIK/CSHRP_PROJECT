﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prg9for
{
    class Program
    {
        static void Main(string[] args)
        {
            //for loop 

            int i = 1;
            for (i = 1; i < 6; i++)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
        }
    }
}
