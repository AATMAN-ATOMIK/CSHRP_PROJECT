﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace updatedelete
{
    public partial class Form2 : Form
    {
        DataTable d = new DataTable();
        int cr = 0;
        int tr,flag=0;
        string oname;
        string opass;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            disp();
            //griddat();
        }   

        private void disp()
        {
            d.Reset();
            string sel = "Select * from updet";
            SqlDataAdapter adapter = new SqlDataAdapter(sel, Class1.cn);
            d.AcceptChanges();
            adapter.Fill(d);
            tr = d.Rows.Count;
            //dataGridView1.DataSource = d;
            //griddat();
            if (tr >= 1)
            {
                navigate();
            }
            else 
            {
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }

        //Navigation Section
        private void navigate()
        {
            textBox1.Text = d.Rows[cr]["name"].ToString();
            textBox2.Text = d.Rows[cr]["password"].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cr = 0;
            navigate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cr = tr - 1;
            navigate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (cr < tr - 1)
            {
                cr++;
                navigate();
            }
            else
            {
                MessageBox.Show("Already on first record!!!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (cr > 0)
            {
                cr--;
                navigate();
            }
            else
            {
                MessageBox.Show("No more records in database!!!","Info",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        //Update Section
        private void button6_Click(object sender, EventArgs e)
        {
            
            if (flag == 0)
            {
                button6.Text = "Save";
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                oname = textBox1.Text;
                opass = textBox2.Text;
                flag = 1;
            }
            else if (flag == 1)
            {
                string up = "Update updet set name='"+textBox1.Text+"',password='"+textBox2.Text+"' where name='"+oname+"' and password ='"+opass+"'";
                SqlDataAdapter dup = new SqlDataAdapter(up, Class1.cn);
                DataTable d = new DataTable();
                int a = dup.Fill(d);
                MessageBox.Show(" a =  "+ a);
                flag = 0;
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                button6.Text = "Update";
                disp();
               // griddat();
            }
        }

        //Delete Section

        private void button7_Click(object sender, EventArgs e)
        {
            string del = "Delete from updet where name = '" + textBox1.Text + "' and password = '" + textBox2.Text + "'";
            SqlDataAdapter dde = new SqlDataAdapter(del, Class1.cn);
            DataTable ddt = new DataTable();
            dde.Fill(ddt);
            tr--;
            cr = 0;
            disp();
            
        }

        /*private void griddat()
        {
            string sel = "select * from updet";
            SqlDataAdapter adapter = new SqlDataAdapter(sel, Class1.cn);
            DataTable t =  new DataTable();
            t.AcceptChanges();
            adapter.Fill(t);
            dataGridView1.DataSource = d;
        }*/
    }
}
