﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AROP
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            char c;
            Console.WriteLine("Enter two numbers and operator : ");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToChar(Console.Read());
            switch (c)
            {
                case '+':
                    Console.WriteLine("Sum : " + (a+b));
                    break;
                case '-':
                    Console.WriteLine("Sub : " + (a-b));
                    break;
                case '*':
                    Console.WriteLine("Mul : " + (a*b));
                    break;
                case '/':
                    Console.WriteLine("Div : " + (a/b));
                    break;
                case '%':
                    Console.WriteLine("Mod : " + (a%b));
                    break;
                default:
                    Console.WriteLine("Enter valid arithmetic operator *_*");
                    break;
            }
        }
    }
}